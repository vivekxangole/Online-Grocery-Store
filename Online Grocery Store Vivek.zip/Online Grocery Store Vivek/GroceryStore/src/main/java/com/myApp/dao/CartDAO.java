package com.myApp.dao;

import com.myApp.Dto.CartDTO;

public interface CartDAO {

	public void SavetoCart(CartDTO cartDTO);

	
}
