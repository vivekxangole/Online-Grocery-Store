package com.myApp.service;

import java.util.List;

import com.myApp.Dto.BillingDTO;
import com.myApp.Dto.OrdersDTO;

public interface BillingService {

	public void saveBillDetails(BillingDTO billingDTO);
	

}
