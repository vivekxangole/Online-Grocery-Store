package com.myApp.dao;

import com.myApp.Dto.UpdatePasswordDTO;

public interface UpdatePasswordDAO {

	public void updatePassword(UpdatePasswordDTO updatePasswordDTO);
}
